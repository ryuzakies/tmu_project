(function($) {
	// fungsi dijalankan setelah seluruh dokumen ditampilkan
	$(document).ready(function(e) {
		$('.ajax').click(function(e){
			//alert('test');
			$("#content_inti").html("<div align='center' style='padding-top:15px;'><i class='fa fa-spinner fa-spin fa-lg'></i></div>");
			e.preventDefault();
			$.get($(this).attr('href'), function(Res){
				$('#content_inti').html(Res);
			});
			this.stop();
		});	
	});
}) (jQuery);
