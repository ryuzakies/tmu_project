<?php 
	if(!defined('BASEPATH')) exit('No direct script access allowed');
	/**
	* 
	*/
	class Model_proyek extends CI_Model
	{
		private $key 	= 'id';
		private $table 	= 'tbl_proyek';

		function __construct()
		{
			parent::__construct();
		}

		function countDataAll(){
			return $this->db->count_all($this->table);
		}

		function save($data){
			$this->db->insert($this->table, $data);
		}

		function update($key, $data){
			$this->db->where($this->key, $key);
    		$this->db->update($this->table, $data);
		}

		function delete($data){
			$this->db->where($this->key, $data);
    		$this->db->delete($this->table);
		}

		function countDataItemProyek(){
			return $this->db->count_all("tbl_item_proyek");
		}

		function show() {
		  	$query = $this->db->get($this->table);
        	return $query->result_array();
	    }

		function showSelectedData($data) {
			$this->db->where('id', $data);
		  	$query = $this->db->get($this->table);
        	return $query->result_array();
	    }

	    function comboKlasifikasi(){
			$queryCombo = $this->db->query("SELECT * FROM tbl_klasifikasi");
			return $queryCombo->result_array();
		}
	}
?>