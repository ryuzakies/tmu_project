<?php 
	if(!defined('BASEPATH')) exit('No direct script access allowed');
	/**
	* 
	*/
	class Model_barang extends CI_Model
	{
		private $key 	= 'id';
		private $table 	= 'tbl_barang';
		private $table_klasifikasi 	= 'tbl_klasifikasi';

		function __construct()
		{
			parent::__construct();
		}

		function countDataAll(){
			return $this->db->count_all($this->table);
		}

		function save($data){
			$this->db->insert($this->table, $data);
		}

		function update($key, $data){
			$this->db->where($this->key, $key);
    		$this->db->update($this->table, $data);
		}

		function delete($data){
			$this->db->where($this->key, $data);
    		$this->db->delete($this->table);
		}

		function show($data) {
			$this->db->select('*');
			$this->db->from($this->table_klasifikasi);
			$this->db->join($this->table, 'tbl_klasifikasi.id = tbl_barang.id_klasifikasi');
			if (!empty($data)) {
				$this->db->where($this->table.'.id', $data);
			}
			$query = $this->db->get();
			return $query->result_array();
	    }

		function showSelectedData($data) {
			$this->db->where('id', $data);
		  	$query = $this->db->get($this->table);
        	return $query->result_array();
	    }

		function showSelectedKlasifikasi($data) {
			$this->db->where('id', $data);
		  	$query = $this->db->get($this->table_klasifikasi);
        	return $query->result_array();
	    }

		function showSelectedAllData($data) {
			$this->db->where('id_klasifikasi', $data['id_klasifikasi']);
			$this->db->where('barang', $data['barang']);
			$this->db->where('spesifikasi', $data['spesifikasi']);
			$this->db->where('merk', $data['merk']);
			$this->db->where('type', $data['type']);
		  	$query = $this->db->get($this->table);
        	return $query->result_array();
	    }

	    function comboKlasifikasi(){
			$queryCombo = $this->db->query("SELECT * FROM tbl_klasifikasi");
			return $queryCombo->result_array();
		}		

		function lastIdDataBarang(){
			$query = $this->db->query("SELECT MAX(id) AS last_id FROM ".$this->table."");

			if ($query->num_rows() == 1) {
				foreach($query->result() as $row)
				{
					return $row->last_id;
				}
			}
			else{
				return false;
			}
		}
	}
?>