<?php 
	if(!defined('BASEPATH')) exit('No direct script access allowed');
	/**
	* 
	*/
	class Model_klasifikasi_barang extends CI_Model
	{
		private $key 	= 'id';
		private $table 	= 'tbl_klasifikasi';

		function __construct()
		{
			parent::__construct();
		}

		function countDataAll(){
			return $this->db->count_all($this->table);
		}

		function lastData(){
			return $this->db->sql("SELECT LAST(id) FROM tbl_klasifikasi");
		}

		function save($data){
			$this->db->insert($this->table, $data);
		}

		function update($key, $data){
			$this->db->where($this->key, $key);
    		$this->db->update($this->table, $data);
		}

		function delete($data){
			$this->db->where($this->key, $data);
    		$this->db->delete($this->table);
		}

		function updatePublish($data){
			$this->db->set("publish", $data['publish']);
			$this->db->where($this->key, $data['id']);
    		$this->db->update($this->table, $data);
		}

		function show() {
		  	$query = $this->db->get($this->table);
        	return $query->result_array();
	    }

		function showSelectedData($data) {
			$this->db->where('id', $data);
		  	$query = $this->db->get($this->table);
        	return $query->result_array();
	    }

	    function checkData($data){
			$this->db->where($data['field'], $data['key']);
			$query = $this->db->query("SELECT * FROM ".$this->table." WHERE ".$data['field']."='".$data['key']."'");
		  	if($query->num_rows() == 1)
			{
				return true;
			}
			else{
				return false;
			}
	    }
	}
?>