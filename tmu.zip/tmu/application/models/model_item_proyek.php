<?php 
	if(!defined('BASEPATH')) exit('No direct script access allowed');
	/**
	* 
	*/
	class Model_item_proyek extends CI_Model
	{
		private $key 			= 'id';
		private $table 			= 'tbl_item_proyek';
		private $table_barang 	= 'tbl_barang';
		private $table_satuan 	= 'tbl_satuan';

		function __construct()
		{
			parent::__construct();
		}

		function findType($keyword){
			$this->db->like('type', $keyword,'after');
			$this->db->group_by('type');
			$query = $this->db->get('tbl_barang');
			return $query->result_array();
		}

		function findBarang($keyword){
			$this->db->like('barang', $keyword,'after');
			$this->db->group_by('barang');
			$query = $this->db->get('tbl_barang');
			return $query->result_array();
		}

		function findMerk($keyword){
			$this->db->like('merk', $keyword,'after');
			$this->db->group_by('merk');
			$query = $this->db->get('tbl_barang');
			return $query->result_array();
		}

		function findSpesifikasi($keyword){
			$this->db->like('spesifikasi', $keyword,'after');
			$this->db->group_by('spesifikasi');
			$query = $this->db->get('tbl_barang');
			return $query->result_array();
		}

		function countDataAll(){
			return $this->db->count_all($this->table);
		}

		function save($data){
			$this->db->insert($this->table, $data);
		}

		function update($key, $data){
			$this->db->where($this->key, $key);
    		$this->db->update($this->table, $data);
		}

		function delete($data){
			$this->db->where($this->key, $data);
    		$this->db->delete($this->table);
		}

		function updatePublish($data){
			$this->db->set("publish", $data['publish']);
			$this->db->where($this->key, $data['id']);
    		$this->db->update($this->table, $data);
		}

		function show() {
			$this->db->select('*');    
			$this->db->from($this->table);
			$this->db->join($this->table_barang, 'tbl_barang.id = tbl_item_proyek.id_barang');
			$this->db->join($this->table_satuan, 'tbl_satuan.id = tbl_item_proyek.id_satuan');
		  	$query = $this->db->get();
        	return $query->result_array();
	    }

		function showSelectedData($data) {
			$this->db->select('*, tbl_item_proyek.id AS id_item');    
			$this->db->from($this->table);
			$this->db->join($this->table_barang, 'tbl_barang.id = tbl_item_proyek.id_barang');
			$this->db->join($this->table_satuan, 'tbl_satuan.id = tbl_item_proyek.id_satuan');
			$this->db->where('tbl_item_proyek.id_proyek', $data);    
		  	$query = $this->db->get();
        	return $query->result_array();
	    }

		function showSelectedBarang($data) {
			$this->db->where('barang', $data['barang']);
			$this->db->where('spesifikasi', $data['spesifikasi']);
			$this->db->where('merk', $data['merk']);
			$this->db->where('type', $data['type']);
		  	$query = $this->db->get($this->table_barang);
		  	if($query->num_rows() == 1)
			{ return true; }
			else
			{ return false; }
	    }

		function showSelectedSatuan($data) {
			$this->db->where('satuan', $data['satuan']);
		  	$query = $this->db->get($this->table_satuan);
		  	if($query->num_rows() == 1)
			{ return true; }
			else
			{ return false; }
	    }

		function showBarang($data) {
			$this->db->where('barang', $data['barang']);
			$this->db->where('spesifikasi', $data['spesifikasi']);
			$this->db->where('merk', $data['merk']);
			$this->db->where('type', $data['type']);
		  	$query = $this->db->get($this->table_barang);
        	return $query->result_array();
	    }

		function showSatuan($data) {
			$this->db->where('satuan', $data['satuan']);
		  	$query = $this->db->get($this->table_satuan);
        	return $query->result_array();
	    }

		function saveDataBarang($data){
			$this->db->insert($this->table_barang, $data);
		}

		function saveDataSatuan($data){
			$this->db->insert($this->table_satuan, $data);
		}

	    function comboKlasifikasi(){
			$queryCombo = $this->db->query("SELECT * FROM tbl_klasifikasi");
			return $queryCombo->result_array();
		}
	}
?>