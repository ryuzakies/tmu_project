<?php 
	if(!defined('BASEPATH')) exit('No direct script access allowed');
	/**
	* 
	*/
	class Model_main extends CI_Model
	{
		private $key 				= 'id';
		private $table_barang 		= 'tbl_barang';
		private $table_klasifikasi 	= 'tbl_klasifikasi';
		private $table_proyek 	= 'tbl_proyek';

		function __construct()
		{
			parent::__construct();
		}

		function countDataBarang(){
			return $this->db->count_all($this->table_barang);
		}

		function countDataKlasifikasi(){
			return $this->db->count_all($this->table_klasifikasi);
		}

		function countDataProyek(){
			return $this->db->count_all($this->table_proyek);
		}

		function dataKlasifikasi(){
		  	$query = $this->db->get($this->table_klasifikasi);
        	return $query->result_array();
		}

		function dataProyek(){
		  	$query = $this->db->get($this->table_proyek);
        	return $query->result_array();
		}

		function dataBarang(){
			$this->db->select('*');
			$this->db->from($this->table_klasifikasi);
			$this->db->join($this->table_barang, 'tbl_klasifikasi.id = tbl_barang.id_klasifikasi');
			$query = $this->db->get();
			return $query->result_array();
		}

		function lastIdDataKlasifikasi(){
			$query = $this->db->query("SELECT MAX(id) AS last_id FROM tbl_klasifikasi");

			if ($query->num_rows() == 1) {
				foreach($query->result() as $row)
				{
					return $row->last_id;
				}
			}
			else{
				return false;
			}
		}

		function lastIdDataProyek(){
			$query = $this->db->query("SELECT MAX(id) AS last_id FROM tbl_proyek");

			if ($query->num_rows() == 1) {
				foreach($query->result() as $row)
				{
					return $row->last_id;
				}
			}
			else{
				return false;
			}
		}

		function lastIdDataBarang(){
			$query = $this->db->query("SELECT MAX(id) AS last_id FROM tbl_barang");

			if ($query->num_rows() == 1) {
				foreach($query->result() as $row)
				{
					return $row->last_id;
				}
			}
			else{
				return false;
			}
		}
	}
?>