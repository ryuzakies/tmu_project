    <!-- Bootstrap 3.3.2 JS -->
    <script src="assets/template/adminlte/plugins/jQuery/jQuery-2.1.4.min.js" type="text/javascript"></script>
    <script src="assets/template/adminlte/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>

    <!-- DATA TABES SCRIPT -->
    <script src="assets/template/adminlte/plugins/datatables/jquery.dataTables.min.js" type="text/javascript"></script>
    <script src="assets/template/adminlte/plugins/datatables/dataTables.bootstrap.min.js" type="text/javascript"></script>

    <!-- JQUERY Framework -->
    <!--<script type="text/javascript" src="assets/jquery/jquery.js"></script>  -->  
    <script type="text/javascript" src="assets/jquery/jquery-ui.js"></script>    
    <script type="text/javascript" src="assets/js/aplikasi.js"></script>    
    
    <!-- iCheck 1.0.1 -->
    <script src="assets/template/adminlte/plugins/iCheck/icheck.min.js" type="text/javascript"></script>

    <!-- FastClick -->    
    <script src="assets/template/adminlte/plugins/fastclick/fastclick.min.js" type="text/javascript"></script>

    <!-- AdminLTE App -->
    <script src="assets/template/adminlte/dist/js/app.min.js" type="text/javascript"></script>

    <!-- Sparkline -->
    <script src="assets/template/adminlte/plugins/sparkline/jquery.sparkline.min.js" type="text/javascript"></script>

    <!-- jvectormap -->
    <script src="assets/template/adminltep/lugins/jvectormap/jquery-jvectormap-1.2.2.min.js" type="text/javascript"></script>
    <script src="assets/template/adminltep/lugins/jvectormap/jquery-jvectormap-world-mill-en.js" type="text/javascript"></script>

    <!-- SlimScroll 1.3.0 -->
    <script src="assets/template/adminlte/plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>

    <!-- ChartJS 1.0.1 -->
    <script src="assets/template/adminlte/plugins/chartjs/Chart.min.js" type="text/javascript"></script>

    <!-- Loadie -->
    <!--<script src="assets/loadie/js/jquery.min.js"></script>
    <script src="assets/loadie/js/jquery.loadie.js"></script>-->

    <!-- AdminLTE dashboard demo (This is only for demo purposes) 
    <script src="assets/template/adminlte/dist/js/pages/dashboard2.js" type="text/javascript"></script>-->

    <!-- AdminLTE for demo purposes -->
    <!--<script src="assets/template/adminlte/dist/js/demo.js" type="text/javascript"></script>-->

    <!-- Select2
    <script src="assets/template/adminlte/plugins/select2/select2.full.min.js" type="text/javascript"></script> -->
    <script src="assets/template/adminlte/plugins/daterangepicker/daterangepicker.js" type="text/javascript"></script>
    <!-- InputMask 
    <script src="assets/template/adminlte/plugins/input-mask/jquery.inputmask.js" type="text/javascript"></script>
    <script src="assets/template/adminlte/plugins/input-mask/jquery.inputmask.date.extensions.js" type="text/javascript"></script>
    <script src="assets/template/adminlte/plugins/input-mask/jquery.inputmask.extensions.js" type="text/javascript"></script>