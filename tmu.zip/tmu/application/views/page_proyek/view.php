<script type="text/javascript">	
	$("#example1").DataTable({
		"scrollX": false
	});
	
	$('.ajax_in').click(function(e){
		$("#content_inti").html("<div align='center' style='padding-top:15px;'><i class='fa fa-spinner fa-spin fa-lg'></i></div>");
		e.preventDefault();
		$.get($(this).attr('href'), function(Res){
			$('#content_inti').html(Res);
		});
	})
</script>
<table id="example1" class="table table-bordered table-striped" width="100%">
	<thead>
	<tr>
		<th width="15%">Nomer Proyek</th>
		<th width="20%">Nama Proyek</th>
		<th width="45%">Lokasi Proyek</th>
		<th width="20%">Menu</th>
	</tr>
	</thead>
	<tbody>
	<?php if (!empty($query)) {  $x=1; ?>
	<?php foreach ($query as $row) { ?>
	<tr id="tr_<?php echo $row['id']; ?>">
		<td>
			<input type="hidden" value="<?php echo $row['nama_proyek']; ?>" id="hide_proyek_<?php echo $row['id']; ?>">
			<input type="hidden" value="<?php echo $row['id']; ?>" id="hide_id_<?php echo $row['id']; ?>">
			<span id="val_nomer_<?php echo $row['id']; ?>"><?php echo $row['nomer_proyek']; ?></span>
		</td>
		<td><span id="val_proyek_<?php echo $row['id']; ?>"><?php echo $row['nama_proyek']; ?></span></td>
		<td><span id="val_lokasi_<?php echo $row['id']; ?>"><?php echo $row['lokasi_proyek']; ?></span></td>
		<td>
			<div class="btn-group">
				<a class="btn btn-success btn-sm" onclick="editData(<?php echo $row['id']; ?>);" href="javascript::;"><i class="fa fa-pencil"></i></a>
				<a onclick="hapusData(<?php echo $row['id']; ?>);" class="btn btn-danger  btn-sm"><i class="fa fa-eraser"></i></a>
				<a href="<?php echo site_url('controller_proyek/pageItem/'.$row['id'].''); ?>" class="btn btn-primary btn-sm ajax_in"><i class="fa fa-files-o"></i></a>
			</div>
		</td>
	</tr>
	<?php $x++; } ?>
	<?php } ?>
	</tbody>
</table>