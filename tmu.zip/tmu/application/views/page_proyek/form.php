<script type="text/javascript">
	$('#btnHapusProyek').click(function(){
		dataString = "id="+id;

		//document.getElementById('LastId').value 	= parseInt($('#LastId').val())-1;  
		//document.getElementById('CountData').value 	= parseInt($('#CountData').val())-1; 
		var urlx = "<?php echo site_url('controller_proyek/delete'); ?>";
		$(".modal-body").html("<div align='center'><i class='fa fa-spinner fa-spin fa-lg'></i></div>");
    	$.ajax({
           type 	: "POST",
           url 		: urlx,
           dataType : 'json',
           data 	: dataString,
           success: function(html)
           {
           		if (html) {
					$(".modal-body").html("Data berhasil dihapus");
		    		document.getElementById('tr_'+html.id).style.display 	= "none"; 
		    		document.getElementById('btnHapus').style.display 		= "none";  
		    	}
           }
         });
	});


  	$('#btnSaveProyek, #btnUpdateProyek').click(function(event){
  		event.preventDefault();
  		var operasi = $(this).attr('value');
  		dataString 	= $("#myForm").serialize();

  		if (operasi=="Simpan") { 
  			urlx = "<?php echo base_url(); ?>"+"index.php/controller_proyek/insert"; 
  		}else if(operasi=="Perbarui"){
  			urlx = "<?php echo base_url(); ?>"+"index.php/controller_proyek/update"; 
  		}
		$(".modal-body").html("<div align='center'><i class='fa fa-spinner fa-spin fa-lg'></i></div>");
  		jQuery.ajax({
  			type 	: "POST",
  			url 	: urlx,
  			dataType: 'json',
  			data 	: dataString,
  			success : function(res){
  				if (res) {
			    document.getElementById('LastId').value 	= parseInt($('#LastId').val())+1;  
			    document.getElementById('CountData').value 	= parseInt($('#CountData').val())+1; 
  					if (operasi=="Simpan") {
  						$('#example1').dataTable().fnAddData( [
							"<span id='val_nomer_"+$('#LastId').val()+"'>"+res.nomer_proyek+"</span>",
							"<span id='val_proyek_"+$('#LastId').val()+"'>"+res.nama_proyek+"</span>",
							"<span id='val_lokasi_"+$('#LastId').val()+"'>"+res.lokasi_proyek+"</span>",
							"<div class='btn-group'>"+
							"<a class='btn btn-success btn-sm' onclick='editData("+$('#LastId').val()+");'><i class='fa fa-pencil'></i></a>"+
							"<a class='btn btn-danger  btn-sm' onclick='hapusData("+$('#LastId').val()+");'><i class='fa fa-eraser'></i></a></div>"+
					        "<a href='"+<?php echo site_url('controller_proyek/pageItem/'); ?>+"' class='btn btn-primary btn-sm'><i class='fa fa-files-o'></i></a>"
						]);	
					};
  					if (operasi=="Perbarui") {  						
						$('#val_nomer_'+id).html(res.nomer_proyek);
						$('#val_proyek_'+id).html(res.nama_proyek);
						$('#val_lokasi_'+id).html(res.lokasi_proyek);
  					};
  				}				
				$(".modal-body").html("Data berhasil disimpan");
  			}
  		});
		this.stop();
  	});

</script>
<?php 
	if (!empty($query)) {
		foreach ($query as $row) {
			$id 	= $row['id'];
			$nomer 	= $row['nomer_proyek'];
			$proyek = $row['nama_proyek'];
			$lokasi = $row['lokasi_proyek'];
			$tanggal= $row['tanggal'];
		}
	}else{
		$nomer 	= "";
		$proyek = "";
		$lokasi = "";
		$tanggal = date("Y-m-d");
	}
?>

	<div class="row">
		<div class="col-md-12">	
			    	<div class="col-md-12">
			    		<?php
			    			$attribute = array(
			    							'name'	=>'myForm',
			    							'id'	=>'myForm',
			    							'class'	=>'form-horizontal'
			    						);
			    			echo form_open('#', $attribute);
			    		?>
			    		<?php 
			    			if (!empty($query) && ($operasi=='update' || $operasi=='delete')) {
			    				echo form_input(
			    					array(
			    						'name' 	=> 'id',
			    						'id' 	=> 'id',
			    						'type' 	=> 'hidden',
			    						'value'	=> ''.$id.''
			    					)
			    				);
			    			}
			    		?>
			    		<?php if ($operasi!='delete') {  ?>
                  		<div class="box-body">
                  			<div class="form-group">
                  			<label for="nomor">Nomor Proyek</label>
					    		<?php 
					    			echo form_input(
					    				array(
					    					'type'			=> 'text',
					    					'name'			=> 'nomer',
					    					'id'			=> 'nomer',
					    					'class'			=> 'form-control',
					    					'placeholder'	=> 'Nomer Proyek',
					    					'value' 		=> ''.$nomer.''
					    				)
					    			);
					    		?>
				    		</div>
                  			<div class="form-group">
                  			<label for="proyek">Nama Proyek</label>
					    		<?php 
					    			echo form_input(
					    				array(
					    					'type'			=> 'text',
					    					'name'			=> 'proyek',
					    					'id'			=> 'proyek',
					    					'class'			=> 'form-control',
					    					'placeholder'	=> 'Nama Proyek',
					    					'value' 		=> ''.$proyek.''
					    				)
					    			);
					    		?>
				    		</div>
				    		<div class="form-group">
                  			<label for="lokasi">Lokasi Proyek</label>
					    		<?php 
					    			echo form_textarea(
					    				array(
					    					'name'			=> 'lokasi',
					    					'id'			=> 'lokasi',
					    					'rows'			=> 4,
					    					'class'			=> 'form-control',
					    					'placeholder'	=> 'Lokasi Proyek',
					    					'value' 		=> ''.$lokasi.''
					    				)
					    			);
					    		?>
				    		</div>
				    		<div class="form-group">
                  			<label for="tanggal">Tanggal</label>
				    		<?php 
				    				echo form_input(
				    					array(
				    						'name' 	=> 'tanggal',
				    						'id' 	=> 'tanggal',
				    						'type' 	=> 'text',
				    						'class' => 'form-control',
				    						'value'	=> ''.$tanggal.''
				    					)
				    				);
				    		?>
				    		</div>
			    		</div>
			    		<?php }
			    		else{
			    			echo "Anda yakin untuk menghapus ".$proyek."";
			    		} ?>
			    		<div align="right">
				    		<?php 
				    				echo form_input(
				    					array(
				    						'data-dismiss' => 'modal',
				    						'name' 	=> 'modal-btn-close',
				    						'id' 	=> 'modal-btn-close',
				    						'type' 	=> 'button',
				    						'class' => 'btn btn-default',
				    						'value'	=> 'Keluar'
				    					)
				    				);
				    		?>		
				    		<?php 
				    			if ($operasi=="delete") {
				    				echo form_input(
				    					array(
				    						'name' 	=> 'btnHapusProyek',
				    						'id' 	=> 'btnHapusProyek',
				    						'type' 	=> 'button',
				    						'class' => 'btn btn-danger',
				    						'value'	=> 'Hapus'
				    					)
				    				);
				    			}
				    		?>		 
				    		<?php
					    		if (!empty($query) && $operasi=='update') {					    			
				    				echo form_input(
				    					array(
				    						'name' 	=> 'btnUpdateProyek',
				    						'id' 	=> 'btnUpdateProyek',
				    						'type' 	=> 'button',
				    						'class' => 'btn btn-success',
				    						'value'	=> 'Perbarui'
				    					)
				    				);
					    		}else if ($operasi=='create') {  
				    				echo form_input(
				    					array(
				    						'name' 	=> 'btnSaveProyek',
				    						'id' 	=> 'btnSaveProyek',
				    						'type' 	=> 'button',
				    						'class' => 'btn btn-primary',
				    						'value'	=> 'Simpan'
				    					)
				    				);
				    			}
				    		?>			   
				    		</div> 		
			    		<?php 
			    			echo form_close();
			    		?>
			    	</div>
			    </div>
	</div>