<script type="text/javascript">
	$('#btnHapusKlasifikasi').click(function(){
		dataString = "id="+id;
		//document.getElementById('LastId').value 	= parseInt($('#LastId').val())-1;  
		document.getElementById('CountData').value 	= parseInt($('#CountData').val())-1; 
		var urlx = "<?php echo site_url('controller_klasifikasi/delete'); ?>";
		$(".modal-body").html("<div align='center'><i class='fa fa-spinner fa-spin fa-lg'></i></div>");
    	$.ajax({
           type 	: "POST",
           url 		: urlx,
           dataType : 'json',
           data 	: dataString,
           success: function(html)
           {
           		if (html) {
					$(".modal-body").html("Data berhasil dihapus");
		    		document.getElementById('tr_'+html.id).style.display 	= "none"; 
		    		document.getElementById('btnHapus').style.display 		= "none";  
		    	}
           }
         });
	});

  	$('#btnSaveKlasifikasi, #btnUpdateKlasifikasi').click(function(event){
  		event.preventDefault();
  		var operasi = $(this).attr('value');
	    dataString = $("#myForm").serialize();
	    if (operasi=="Simpan") {
	    	urlx = "<?php echo base_url(); ?>"+"index.php/controller_klasifikasi/insert"; 
	    }
	    else if (operasi=="Perbarui"){
	    	urlx = "<?php echo base_url(); ?>"+"index.php/controller_klasifikasi/update";
	    }
	    
		$(".modal-body").html("<div align='center'><i class='fa fa-spinner fa-spin fa-lg'></i></div>");
  		jQuery.ajax({
  			type 	: "POST",
  			url 	: urlx,
  			dataType: 'json',
  			data 	: dataString,
  			success : function(res){
  				if (res) {
			    document.getElementById('LastId').value 	= parseInt($('#LastId').val())+1;  
			    document.getElementById('CountData').value 	= parseInt($('#CountData').val())+1; 
  					if (operasi=="Simpan") {
  						$('#example1').dataTable().fnAddData([
  							$('#CountData').val(),
							"<span id='val_klasifikasi_"+$('#LastId').val()+"'>"+res.klasifikasi+"</span>",
							"<span id='val_deskripsi_"+$('#LastId').val()+"'>"+res.deskripsi+"</span>",
							"<div class='btn-group'>"+
							"<a class='btn btn-success btn-sm' onclick='editData("+$('#LastId').val()+");'><i class='fa fa-pencil'></i></a>"+
							"<a type='button' class='btn btn-primary btn-sm'><i class='fa fa-file'></i></a>"+
							"<a class='btn btn-danger  btn-sm' onclick='hapusData("+$('#LastId').val()+");'><i class='fa fa-eraser'></i></a></div>"
						]);	
					};
  					if (operasi=="Perbarui") {  						
						$('#val_klasifikasi_'+id).html(res.klasifikasi);
						$('#val_deskripsi_'+id).html(res.deskripsi);
  					};
  				}				
				$(".modal-body").html("Data berhasil disimpan");
  			}
  		});
		this.stop();
  	});

</script>
<?php 
	if (!empty($query)) {
		foreach ($query as $row) {
			$id 			= $row['id'];
			$klasifikasi 	= $row['klasifikasi'];
			$deskripsi 		= $row['deskripsi'];
		}
	}else{
			$id 			= "";
			$klasifikasi 	= "";
			$deskripsi 		= "";
	}
?>

	<div class="row">
		<div class="col-md-12">	
			    	<div class="col-md-12">
			    		<?php
			    			$attribute = array(
			    							'name'	=>'myForm',
			    							'id'	=>'myForm',
			    							'class'	=>'form-horizontal'
			    						);
			    			echo form_open('#', $attribute);
			    		?>
			    		<?php 
			    			if (!empty($query) && ($operasi=="update" || $operasi=="delete")) {
			    				echo form_input(
			    					array(
			    						'name' 	=> 'id',
			    						'id' 	=> 'id',
			    						'type' 	=> 'hidden',
			    						'value'	=> ''.$id.''
			    					)
			    				);
			    			}
			    		?>
			    		<?php 
			    			if ($operasi != "delete") {
			    		?>
                  		<div class="box-body">
                  			<div class="form-group">
                  			<label for="Klasifikasi">Klasifikasi</label>
					    		<?php 
					    			echo form_input(
					    				array(
					    					'type'			=> 'text',
					    					'name'			=> 'klasifikasi',
					    					'id'			=> 'klasifikasi',
					    					'class'			=> 'form-control',
					    					'placeholder'	=> 'Klasifikasi Barang',
					    					'value' 		=> ''.$klasifikasi.''
					    				)
					    			);
					    		?>
				    		</div>
				    		<div class="form-group">
                  			<label for="deskripsi">Deskripsi</label>
					    		<?php 
					    			echo form_textarea(
					    				array(
					    					'name'			=> 'deskripsi',
					    					'id'			=> 'deskripsi',
					    					'rows'			=> 4,
					    					'class'			=> 'form-control',
					    					'placeholder'	=> 'Deskripsi',
					    					'value' 		=> ''.$deskripsi.''
					    				)
					    			);
					    		?>
				    		</div>
			    		</div>
			    		<?php }
			    		else{
			    			echo "Anda yakin untuk menghapus data ".$klasifikasi."";
			    		} ?>
			    			<div align="right">
			    			<?php 
				    				echo form_input(
				    					array(
				    						'data-dismiss' => 'modal',
				    						'name' 	=> 'modal-btn-close',
				    						'id' 	=> 'modal-btn-close',
				    						'type' 	=> 'button',
				    						'class' => 'btn btn-default',
				    						'value'	=> 'Keluar'
				    					)
				    				);
				    		?>		

			    			<?php 
			    				if ($operasi=="delete") {
				    				echo form_input(
				    					array(
				    						'name' 	=> 'btnHapusKlasifikasi',
				    						'id' 	=> 'btnHapusKlasifikasi',
				    						'type' 	=> 'button',
				    						'class' => 'btn btn-danger',
				    						'value'	=> 'Hapus'
				    					)
				    				);
			    				}
				    		?>	 
				    		<?php
					    		if (!empty($query) && $operasi=="update") {					    			
				    				echo form_input(
				    					array(
				    						'name' 	=> 'btnUpdateKlasifikasi',
				    						'id' 	=> 'btnUpdateKlasifikasi',
				    						'type' 	=> 'button',
				    						'class' => 'btn btn-success',
				    						'value'	=> 'Perbarui'
				    					)
				    				);
					    		}else if($operasi=="create"){  
				    				echo form_input(
				    					array(
				    						'name' 	=> 'btnSaveKlasifikasi',
				    						'id' 	=> 'btnSaveKlasifikasi',
				    						'type' 	=> 'button',
				    						'class' => 'btn btn-primary',
				    						'value'	=> 'Simpan'
				    					)
				    				);
				    			}
				    		?>		
			    		<?php 
			    			echo form_close();
			    		?>
			    		</div>
			    	</div>
			    </div>
	</div>