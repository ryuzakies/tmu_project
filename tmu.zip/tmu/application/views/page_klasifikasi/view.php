<script type="text/javascript">	
	$("#example1").DataTable({
		"scrollX": true
	});
</script>
<table id="example1" class="table table-bordered table-striped" width="100%">
	<thead>
		<tr>
			<th width="10%">NO</th>
			<th width="20%">Klasifikasi</th>
			<th width="50%">Deskripsi</th>
			<th width="20%">Menu</th>
		</tr>
	</thead>
	<tbody>
	<?php if (!empty($query)) {  $x=1; ?>
	<?php foreach ($query as $row) { ?>
		<tr id="tr_<?php echo $row['id']; ?>">
			<td>
			<input type="hidden" value="<?php echo $row['id']; ?>" id="hide_id_<?php echo $row['id']; ?>">
			<?php echo $x; ?>
			</td>
			<td><span id="val_klasifikasi_<?php echo $row['id']; ?>"><?php echo $row['klasifikasi']; ?></span></td>
			<td><span id="val_deskripsi_<?php echo $row['id']; ?>"><?php echo $row['deskripsi']; ?></span></td>
			<td>
				<div class="btn-group">
					<a class="btn btn-success btn-sm" onclick="editData(<?php echo $row['id']; ?>);" href="javascript::;"><i class="fa fa-pencil"></i></a>
					<a type="button" class="btn btn-primary btn-sm"><i class="fa fa-file"></i></a>
					<a onclick="hapusData(<?php echo $row['id']; ?>);" class="btn btn-danger  btn-sm"><i class="fa fa-eraser"></i></a>
				</div>
			</td>
		</tr>
	<?php $x++; } ?>
	<?php } ?>
	</tbody>
</table>