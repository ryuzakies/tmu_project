<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<section class="content-header">
	<h1>
    	<?php echo $judul; ?> <small> </small>
	</h1>
	<ol class="breadcrumb">
    	<li><a href="<?php echo base_url(); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"><?php echo $judul; ?></li>
	</ol>
</section>

<section class="content">
	<div class="row">
		<div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-aqua">
                <div class="inner">
                  <h3><?php echo $count; ?></h3>
                  <p>Data Barang</p>
                </div>
                <div class="icon">
                  <i class="fa fa-archive"></i>
                </div>
                <a href="<?php echo site_url('controller_main/pageBarang'); ?>" class="small-box-footer ajax">
                  Detail <i class="fa fa-arrow-circle-right"></i>
                </a>
              </div>
		</div><!-- ./col -->

		<div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-red">
                <div class="inner">
                  <h3><?php echo $count; ?></h3>
                  <p>Project List</p>
                </div>
                <div class="icon">
                  <i class="fa fa-files-o"></i>
                </div>
                <a href="#" class="small-box-footer ajax">
                  Detail <i class="fa fa-arrow-circle-right"></i>
                </a>
              </div>
		</div><!-- ./col -->

    	<div class="col-md-12">
			<div class="box">
				<div class="box-header with-border">
			    	<h3 class="box-title">Monthly Recap Report</h3>
			     	<div class="box-tools pull-right">
						<button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
							<div class="btn-group">
			                	<button class="btn btn-box-tool dropdown-toggle" data-toggle="dropdown"><i class="fa fa-wrench"></i></button>
			                    	<ul class="dropdown-menu" role="menu">
				                        <li><a href="#">Action</a></li>
				                        <li><a href="#">Another action</a></li>
				                        <li><a href="#">Something else here</a></li>
				                        <li class="divider"></li>
				                        <li><a href="#">Separated link</a></li>
			                    	</ul>
							</div>
					</div>
				</div><!-- /.box-header -->
				<div class="box-body">
			    	<div class="row">
			        	<div class="col-md-12">
				        	<p>The page you are looking at is being generated dynamically by CodeIgniter.</p>

							<p>If you would like to edit this page you'll find it located at:</p>
							<code>application/views/welcome_message.php</code>

							<p>The corresponding controller for this page is found at:</p>
							<code>application/controllers/Welcome.php</code>

							<p>If you are exploring CodeIgniter for the very first time, you should start by reading the <a href="user_guide/">User Guide</a>.</p>

						Page rendered in <strong>{elapsed_time}</strong> seconds. <?php echo  (ENVIRONMENT === 'development') ?  'CodeIgniter Version <strong>' . CI_VERSION . '</strong>' : '' ?>
						</div>
					</div><!-- /.row -->
				</div><!-- ./box-body -->
			</div><!-- /.box -->
		</div>
	</div>
</section>