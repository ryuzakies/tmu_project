<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<script class="init" type="text/javascript" language="javascript">
	var operasi = "";
	var id;
    
    $('#tanggalPicker').datepicker({
    	dateFormat:'yy-mm-dd'
    });

	$("#itemProyek").html("<div align='center'><i class='fa fa-spinner fa-spin fa-lg'></i></div>");
	var url = '<?php echo site_url("Controller_item_proyek/selectData"); ?>';
	var id_proyek = $('#id_proyek').val();
	$.post(url, {id:id_proyek} ,function(data) {
		//alert(id);
		$("#itemProyek").html(data).show();
	});

	$("#example1").DataTable({
		'scrollX' : true
	});
	$('.ajax').click(function(e){
		e.preventDefault();
		$.get($(this).attr('href'), function(Res){
			$('#content_inti').html(Res);
		});
	})

	$("#formBarang").autocomplete({
		minLength : 1,
		source:function(req, add){
			$.ajax({
				url:"<?php echo site_url('Controller_item_proyek/lookUpBarang'); ?>",
				dataType:'json',
				type:'POST',
				data: req,
				success:function(data){
					if (data.response == "true") {
						add(data.message);
					}
				},
			});
		},
	});

	$("#formSpesifikasi").autocomplete({
		minLength : 1,
		source:function(req, add){
			$.ajax({
				url:"<?php echo site_url('Controller_item_proyek/lookUpSpesifikasi'); ?>",
				dataType:'json',
				type:'POST',
				data: req,
				success:function(data){
					if (data.response == "true") {
						add(data.message);
					}
				},
			});
		},
	});

	$("#formMerk").autocomplete({
		minLength : 1,
		source:function(req, add){
			$.ajax({
				url:"<?php echo site_url('Controller_item_proyek/lookUpMerk'); ?>",
				dataType:'json',
				type:'POST',
				data: req,
				success:function(data){
					if (data.response == "true") {
						add(data.message);
					}
				},
			});
		},
	});

	$("#formType").autocomplete({
		minLength : 1,
		source:function(req, add){
			$.ajax({
				url:"<?php echo site_url('Controller_item_proyek/lookUpType'); ?>",
				dataType:'json',
				type:'POST',
				data: req,
				success:function(data){
					if (data.response == "true") {
						add(data.message);
					}
				},
			});
		},
	});

	function editData(data){	
		id 		= data;
		operasi = 'update';
		var url = '<?php echo site_url("Controller_proyek/updateData"); ?>';
		//alert('data');
		$('#myModal').fadeIn(400).modal('show');
		$(".modal-title").html("Update Data");

		$.post(url, {id : id} ,function(data) {
			$(".modal-body").html(data).show();
		});
	};

	function hapusData(data){	
		id 		= data;
		operasi = 'hapus';
		//var url = '<?php echo site_url("Controller_klasifikasi/hapusData"); ?>';
		$('#myModal').fadeIn(400).modal('show');
		$(".modal-title").html("Hapus Data");
		$(".modal-body").html("Anda yakin ingin menghapus data "+$("#hide_proyek_"+id).val());
	    document.getElementById('btnPerbarui').style.display 	= "none";  
	    document.getElementById('btnSimpan').style.display 		= "none";  
	    document.getElementById('btnHapus').style.display 		= "";  
	};

	$('#btnHapus').click(function(){
		//alert($('#LastId').val());
		dataString = "id="+id;
		var urlx = "<?php echo site_url('controller_proyek/delete'); ?>";
    	$.ajax({
           type: "POST",
           url: urlx,
           data: dataString,
           success: function(html)
           {
		    	document.getElementById('CountData').value 	= parseInt($('#CountData').val())-1;  
				$(".modal-body").html("Data berhasil dihapus");
	    		document.getElementById('tr_'+id).style.display 	= "none"; 
	    		document.getElementById('btnHapus').style.display 	= "none";  
           }
         });
		this.stop();
	});

  	$('#simpanItem, #btnUpdateBarang').click(function(){
		event.preventDefault();
		var operasi = $(this).attr('value');
	    dataString = $("#myFormItem").serialize();
	    var urlx;
	    if (operasi=="Simpan") {
	    	urlx = "<?php echo base_url(); ?>"+"index.php/Controller_item_proyek/insert"; 
	    }
	    else if (operasi=="Perbarui"){
	    	urlx = "<?php echo site_url('controller_barang/update'); ?>";
	    }

	    //alert(dataString);
    	jQuery.ajax({
  			type 	: "POST",
  			url 	: urlx,
  			dataType: 'json',
  			data 	: dataString,
  			success : function(res){
  				if (res) {
			    //document.getElementById('LastId').value 	= parseInt($('#LastId').val())+1;  
			    //document.getElementById('CountData').value 	= parseInt($('#CountData').val())+1; 
  					if (operasi=="Simpan") {
  						$("#formBarang").val("");
  						$("#formSpesifikasi").val("");
  						$("#formType").val("");
  						$("#formMerk").val("");
  						$("#jumlah").val("");
  						$("#satuan").val("");
  						$("#tanggalPicker").val("");
  						$("#keterangan").val("");

  						//$('#example1').dataTable().fnAddData([
  						//]);	
    					//alert(res.id_barang);
					};
  					if (operasi=="Perbarui") {  						
						$('#val_barang_'+id).html(res.barang);
						$('#val_spesifikasi_'+id).html(res.spesifikasi);
						$('#val_type_'+id).html(res.type+"/"+res.merk);
						$('#val_klasifikasi_'+id).html(res.klasifikasi);
  					};
  				}				
				$(".modal-body").html("Data berhasil disimpan");
  			}
  		});
		this.stop();
  	});
</script>
<?php 
	if (!empty($item)) {
		foreach ($item as $row) {
			$id 	= $row['id'];
			$nomer 	= $row['nomer_proyek'];
			$proyek	= $row['nama_proyek'];
			$lokasi = $row['lokasi_proyek'];
		}
	}
?>
<input type="hidden" value="<?php //echo $last_id; ?>" id="LastId">
<input type="hidden" value="<?php echo $count; ?>" id="CountData">
<input type="hidden" value="<?php echo $id; ?>" id="id_proyek">
<section class="content-header">
	<h1>
    	<?php echo $judul; ?> <small>Page</small>
	</h1>
	<ol class="breadcrumb">
    	<li><a href="<?php echo base_url(); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?php echo base_url(); ?>/index.php/controller_main/pageProyek" class="ajax">Proyek</a></li>
        <li class="active">Daftar Data</li>
	</ol>
</section>

<section class="content">
	<div class="row">
		<a class="ajax" id="tambahData" href="javascript();">
    		<a class="btn btn-app">
            	<i class="fa fa-print"></i> Cetak
            </a>
        </a>

    	<div class="col-md-12">		
			<div class="box">
				<div class="box-body">
			    	<div class="row">
			        	<div class="col-md-12">
			    			<table width="100%">
			    				<tr>
			    					<td width="25%" height="25"><b>Nomer Proyek</b></td>
			    					<td width="5%">=</td>
			    					<td><?php echo $nomer; ?></td>
			    				</tr>
			    				<tr>
			    					<td width="25%" height="25"><b>Nama Proyek</b></td>
			    					<td width="5%">=</td>
			    					<td><?php echo $proyek; ?></td>
			    				</tr>
			    				<tr>
			    					<td width="25%" height="25"><b>Lokasi Proyek</b></td>
			    					<td width="5%">=</td>
			    					<td><?php echo $lokasi; ?></td>
			    				</tr>
			    			</table>
			    		</div>
			    	</div>
			    </div>
			</div>
		</div>

    	<div class="col-md-12">		
			<div class="box box-danger">
				<div class="box-body">
			    	<div class="row">
			        	<div class="col-md-12">
			        		<?php 
			        			$attribut = array(
			        				'name'	=> 'myFormItem',
			        				'id'	=> 'myFormItem',
			        				'class'	=> 'form-horizontal',
			        			);
			        			echo form_open('#',$attribut);

			        			echo form_input(
			        				array(
				        				'name' 	=> 'id_proyek',
				        				'id' 	=> 'id_proyek',
				        				'type' 	=> 'hidden',
				        				'value'	=> ''.$id.'',
			        				)
			        			);
			        		?>
				                <div class="box-header with-border">
				                  <h3 class="box-title">Formulir</h3>
				                </div>
				                <div class="box-body">
				                  <div class="row">
				                    <div class="col-xs-2">
				                      <input type="text" class="form-control"  placeholder="Barang/Jasa" id="formBarang" name="barang">
				                    </div>
				                    <div class="col-xs-2">
				                      <input type="text" class="form-control" placeholder="Spesifikasi" id="formSpesifikasi" name="spesifikasi">
				                    </div>
				                    <div class="col-sm-1">
				                      <input type="text" class="form-control" placeholder="Merk" id="formMerk" name="merk">
				                    </div>
				                    <div class="col-sm-1">
				                      <input type="text" class="form-control" placeholder="Type" id="formType" name="type">
				                    </div>
				                    <div class="col-xs-1">
				                      <input type="text" class="form-control" placeholder="Jumlah" id="jumlah" name="jumlah">
				                    </div>
				                    <div class="col-xs-1">
				                      <input type="text" class="form-control" placeholder="Satuan" id="satuan" name="satuan">
				                    </div>
				                    <div class="col-xs-2">
				                      <input type="text" class="form-control" placeholder="Tanggal" id="tanggalPicker" name="tanggal">
				                    </div>
				                    <div class="col-xs-2 input-group input-group">
				                      <input type="text" class="form-control" placeholder="Keterangan" id="keterangan" name="keterangan">
				                      	<span class="input-group-btn">
					                    	<button class="btn btn-info btn-flat" type="button" id="simpanItem" value="Simpan"><i class="fa fa-save"></i></button>
					                    </span>
				                    </div>
				                  </div>
				            	</div><!-- /.box-body -->
				            	<?php 
				            		echo form_close();
				            	?>
			    		</div>
			    	</div>
			    </div>
			</div>
		</div>

    	<div class="col-md-12">		
			<div class="box">
				<div class="box-body">
			    	<div class="row">
			        	<div class="col-md-12">
			        		<div id="itemProyek"></div>
						</div>
					</div><!-- /.row -->
				</div><!-- ./box-body -->
			</div><!-- /.box -->
		</div>
	</div>
</section>