<script type="text/javascript">	
	$("#example1").DataTable({
		"scrollX": true
	});

	function viewDetailBarang(data){
		operasi = "view"; 
		var url = "<?php echo site_url('Controller_barang/selectData'); ?>";

		$('#myModal').fadeIn(400).modal('show');
		$(".modal-title").html("<i class='fa fa-archive'></i> Detail Data Barang");
		//alert(url);
		$(".modal-body").html("<div align='center'><i class='fa fa-spinner fa-spin fa-lg'></i></div>");
		$.post(url, {id:id, operasi:operasi} ,function(data) {
			$(".modal-body").html(data).show();
		});
	};
</script>

<table id="example1" class="table table-bordered table-striped" width="130%">
	<thead>
		<tr>
			<th width="5%">No</th>
			<th width="20%">Barang/Jasa</th>
			<th width="20%">Spesifikasi</th>
			<th width="15%">Merk / Type</th>
			<th width="10%">Jml</th>
			<th width="10%">Sat</th>
			<th width="20%">Tanggal Dibutuhkan</th>
			<th width="20%">Keterangan</th>
			<th width="20%">Menu</th>
		</tr>
	</thead>
	<tbody>
		<?php if (!empty($query)) {  $x=1; ?>
		<?php foreach ($query as $row) {  
			$newDate = date_create($row['tanggal_dibutuhkan']);
		?>
		<tr id="tr_<?php echo $row['id']; ?>">	
		<input type="hidden" value="<?php echo $row['id_barang']; ?>" name="val_id_barang_<?php echo $row['id_item']; ?>" id="val_id_barang_<?php echo $row['id_item']; ?>">
			<td><span id="val_no_<?php echo $row['id_item']; ?>"><?php echo $x; ?></span></td>
			<td><a href="javascript::;" onclick="viewDetailBarang(<?php echo $row['id_item']; ?>);"><span id="val_barang_<?php echo $row['id_item']; ?>"><?php echo $row['barang']; ?></span></a></td>
			<td><span id="val_spesifikasi_<?php echo $row['id_item']; ?>"><?php echo $row['spesifikasi']; ?></span></td>
			<td><span id="val_merk_<?php echo $row['id_item']; ?>"><?php echo $row['merk']; ?> / <?php echo $row['type']; ?></span></td>
			<td><span id="val_jml_<?php echo $row['id_item']; ?>"><?php echo $row['quantity']; ?></span></td>
			<td><span id="val_satuan_<?php echo $row['id_item']; ?>"><?php echo $row['satuan']; ?></span></td>
			<td><span id="val_tanggal_<?php echo $row['id_item']; ?>"><?php echo date_format($newDate, 'd - F - Y'); ?></span></td>
			<td><span id="val_keterangan_<?php echo $row['id_item']; ?>"><?php echo $row['keterangan']; ?></span></td>
			<td><span id="val_keterangan_<?php echo $row['id_item']; ?>"><?php echo $row['keterangan']; ?></span></td>
		</tr>
		<?php $x++; } ?>
		<?php } ?>
	</tbody>
</table>