<!DOCTYPE html>
<html>
  <head>
    <!-- Tell the browser to be responsive to screen width -->
    <?php echo $_meta; ?>
    <title>AdminLTE 2 | Dashboard</title>
    <?php echo $_include_head; ?>
  </head>
  <body class="skin-blue sidebar-mini">
    <div class="wrapper">
      <?php echo $_navbar_header; ?>
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <section class="sidebar">
          <!-- sidebar: style can be found in sidebar.less -->
            <?php echo $_side_bar; ?>
          <!-- /.sidebar -->
        </section>
      </aside>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Main content -->
        <div id="loadKonten"></div>
        <div id="content_inti">
        
              <?php echo $_content; ?>
        </div>
        <!-- /.content -->
      </div><!-- /.content-wrapper -->


<!-- Modal -->
  <div class="modal fade example-modal" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-primary">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            <h4 class="modal-title"></h4>
          </div>
          <div id="content">
            <div class="modal-body">
              <div id="loadModal" align="center"><i class="fa fa-spinner fa-spin fa-lg"></i></div>
            </div>
          </div>
          <div class="modal-footer">
<!--
            <button data-dismiss="modal" id="modal-btn-close" class="btn btn-default" type="button">Keluar</button>
            <button id="btnPerbarui" class="btn btn-warning btnPerbarui" type="button">Perbarui</button>
            <button id="btnSimpan" class="btn btn-primary btnSimpan" type="button">Simpan</button>
            <button id="btnHapus" class="btn btn-danger btnHapus" type="button">Hapus</button>
-->
          </div>
        </div>
      </div>
    </div>
  </div>
<!-- modal -->

      <footer class="main-footer">
        <?php echo $_footer; ?>
      </footer>

      <!-- Control Sidebar -->
        <?php echo $_control_side; ?>
      <!-- /.control-sidebar-menu -->

      <!-- Add the sidebar's background. This div must be placed
           immediately after the control sidebar -->
      <div class="control-sidebar-bg"></div>

    </div><!-- ./wrapper -->
    <?php echo $_include_footer; ?>
  </body>
</html>
