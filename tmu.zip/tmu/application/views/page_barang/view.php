<script type="text/javascript">	
	$("#example1").DataTable({
		"scrollX": true
	});
</script>
<table id="example1" class="table table-bordered table-striped" width="120%">
	<thead>
		<tr>
			<th width="5%">NO</th>
			<th width="20%">Barang</th>
			<th width="30%">Spesifikasi</th>
			<th width="15%">Merk / Type</th>
			<th width="20%">Klasifikasi</th>
			<?php if (empty($operasi)) { ?><th width="40%">Menu</th><?php } ?>
		</tr>
	</thead>
	<tbody>
	<?php if (!empty($query)) {  $x=1; ?>
	<?php foreach ($query as $row) { ?>
	<tr id="tr_<?php echo $row['id']; ?>">
		<td>
			<input type="hidden" value="<?php echo $row['id']; ?>" id="hide_id_<?php echo $row['id']; ?>">
			<input type="hidden" value="<?php echo $row['barang']; ?>" id="hide_ket_<?php echo $row['id']; ?>">
			<?php echo $x; ?>
		</td>
		<td><span id="val_barang_<?php echo $row['id']; ?>"><?php echo $row['barang']; ?></span></td>
		<td><span id="val_spesifikasi_<?php echo $row['id']; ?>"><?php echo $row['spesifikasi']; ?></span></td>
		<td><span id="val_type_<?php echo $row['id']; ?>"><?php echo $row['merk']; ?> / <?php echo $row['type']; ?></span></td>
		<td><span id="val_klasifikasi_<?php echo $row['id']; ?>"><?php echo $row['klasifikasi']; ?></span></td>
		<?php if(empty($operasi)){ ?>
		<td>
			<div class="btn-group">
				<a class="btn btn-success btn-sm" onclick="editData(<?php echo $row['id']; ?>);" href="javascript::;"><i class="fa fa-pencil"></i></a>
				<a type="button" class="btn btn-primary btn-sm"><i class="fa fa-file"></i></a>
				<a onclick="hapusData(<?php echo $row['id']; ?>);" class="btn btn-danger  btn-sm"><i class="fa fa-eraser"></i></a>
			</div>
		</td>
		<?php } ?>
	</tr>
	<?php $x++; } ?>
	<?php } ?>
	</tbody>
</table>