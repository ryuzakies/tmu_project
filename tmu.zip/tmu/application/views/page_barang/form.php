<script type="text/javascript">
	$('#btnHapusBarang').click(function(){
		dataString = "id="+id;
		//document.getElementById('LastId').value 	= parseInt($('#LastId').val())-1;  
		document.getElementById('CountData').value 	= parseInt($('#CountData').val())-1; 
		var urlx = "<?php echo site_url('Controller_barang/delete'); ?>";
		$(".modal-body").html("<div align='center'><i class='fa fa-spinner fa-spin fa-lg'></i></div>");
    	$.ajax({
           type 	: "POST",
           url 		: urlx,
           dataType : 'json',
           data 	: dataString,
           success: function(html)
           {
           		if (html) {
					$(".modal-body").html("Data berhasil dihapus");
		    		document.getElementById('tr_'+html.id).style.display 	= "none"; 
		    		document.getElementById('btnHapus').style.display 		= "none";  
		    	}
           }
         });
	});

	$('#btnSaveBarang, #btnUpdateBarang').click(function(){
		event.preventDefault();
		var vKlasifikasi = $("#opsi_"+$('#klasifikasi').val()).val();
		var operasi = $(this).attr('value');
	    dataString = $("#myForm").serialize();
	    var urlx;
	    if (operasi=="Simpan") {
	    	urlx = "<?php echo base_url(); ?>"+"index.php/controller_barang/insert"; 
	    }
	    else if (operasi=="Perbarui"){
	    	urlx = "<?php echo site_url('Controller_barang/update'); ?>";
	    }
		$(".modal-body").html("<div align='center'><i class='fa fa-spinner fa-spin fa-lg'></i></div>");
    	jQuery.ajax({
  			type 	: "POST",
  			url 	: urlx,
  			dataType: 'json',
  			data 	: dataString,
  			success : function(res){
  				if (res) {
			    //document.getElementById('LastId').value 	= parseInt($('#LastId').val())+1;  
			    document.getElementById('CountData').value 	= parseInt($('#CountData').val())+1; 
  					if (operasi=="Simpan") {
  						$('#example1').dataTable().fnAddData([
  							"<tr id='tr_"+res.id+"'><td>"+$('#CountData').val()+"</td>",
							"<td><input type='hidden' value="+res.id+" id=hide_id_'"+res.id+"'>" +
							"<input type='hidden' value="+res.barang+" id=hide_ket_'"+res.id+"'>" +
							"<span id='val_barang_"+res.id+"'>"+res.barang+"</span></td>",
							"<td><span id='val_spesifikasi_"+res.id+"'>"+res.spesifikasi+"</span></td>",
							"<td><span id='val_type_"+res.id+"'>"+res.merk+"/"+res.type+"</span></td>",
							"<td><span id='val_klasifikasi_"+res.id+"'>"+vKlasifikasi+"</span></td>",
							"<td><div class='btn-group'>"+
							"<a class='btn btn-success btn-sm' onclick='editData("+res.id+");'><i class='fa fa-pencil'></i></a>"+
							"<a type='button' class='btn btn-primary btn-sm'><i class='fa fa-file'></i></a>"+
							"<a class='btn btn-danger  btn-sm' id='"+res.id+"' onclick='hapusData("+res.id+");'><i class='fa fa-eraser'></i></a></div></td></tr>"
						]);	
					};
  					if (operasi=="Perbarui") {  						
						$('#val_barang_'+id).html(res.barang);
						$('#val_spesifikasi_'+id).html(res.spesifikasi);
						$('#val_type_'+id).html(res.merk+"/"+res.type);
						$('#val_klasifikasi_'+id).html(res.klasifikasi);
  					};
  				}				
				$(".modal-body").html("Data berhasil disimpan");
  			}
  		});
		this.stop();
  	});
</script>
<?php 
	if (!empty($query)) {
		foreach ($query as $row) {
			$id 		= $row['id'];
			$barang 	= $row['barang'];
			$spesifikasi= $row['spesifikasi'];
			$type 		= $row['type'];
			$merk 		= $row['merk'];
			$klasifikasi= $row['id_klasifikasi'];
		}
	}else{
		$barang 		= "";
		$spesifikasi 	= "";
		$type 			= "";
		$merk 			= "";
		$klasifikasi	= "";
	}
?>

	<div class="row">
		<div class="col-md-12">	
			    	<div class="col-md-12">
			    		<?php
			    			$attribute = array(
			    							'name'	=>'myForm',
			    							'id'	=>'myForm',
			    							'class'	=>'form-horizontal'
			    						);
			    			echo form_open('#', $attribute);
			    		?>
			    		<?php 
			    			if (!empty($query) && ($operasi=="update" || $operasi=="delete")) {
			    				echo form_input(
			    					array(
				    					'name' 	=> 'id',
				    					'id' 	=> 'id',
				    					'type' 	=> 'hidden',
				    					'value'	=> $id
			    					)
			    				);
			    			}
			    		if ($operasi!="delete") {
			    		?>
                  		<div class="box-body">
                  			<div class="form-group">
                  			<label for="barang">Barang</label>
					    		<?php 
					    			echo form_input(
					    				array(
					    					'type'			=> 'barang',
					    					'name'			=> 'barang',
					    					'id'			=> 'barang',
					    					'class'			=> 'form-control',
					    					'placeholder'	=> 'Barang',
					    					'value' 		=> $barang
					    				)
					    			);
					    		?>
				    		</div>
				    		<div class="form-group">
                  			<label for="spesifikasi">Spesifikasi</label>
					    		<?php 
					    			echo form_textarea(
					    				array(
					    					'name'			=> 'spesifikasi',
					    					'id'			=> 'spesifikasi',
					    					'rows'			=> 4,
					    					'class'			=> 'form-control',
					    					'placeholder'	=> 'Spesifikasi',
					    					'value' 		=> $spesifikasi
					    				)
					    			);
					    		?>
				    		</div>
				    		<div class="form-group">
                  			<label for="type">Type</label>
					    		<?php 
					    			echo form_input(
					    				array(
					    					'name'			=> 'type',
					    					'id'			=> 'type',
					    					'class'			=> 'form-control',
					    					'placeholder'	=> 'Type',
					    					'value' 		=> $type
					    				)
					    			);
					    		?>
				    		</div>
				    		<div class="form-group">
                  			<label for="merk">Merk</label>
					    		<?php 
					    			echo form_input(
					    				array(
					    					'name'			=> 'merk',
					    					'id'			=> 'merk',
					    					'class'			=> 'form-control',
					    					'placeholder'	=> 'Merk',
					    					'value' 		=> $merk
					    				)
					    			);
					    		?>
				    		</div>
                  		<?php 
                  			if (!empty($combo)) { ?>
				    		<div class="form-group">
                  			<label for="Klasifikasi">Klasifikasi</label>
                  				<?php foreach ($combo as $result): ?>
                  					<input type="hidden" value="<?php echo $result['klasifikasi']; ?>" name="opsi_<?php echo $result['id']; ?>" id="opsi_<?php echo $result['id']; ?>">
                  				<?php endforeach; ?>
                  				<select name="klasifikasi" id="klasifikasi" class="form-control">
                  					<?php foreach ($combo as $result): ?>
                  						<option value="<?php echo $result['id']; ?>" <?php echo $result['id']==$klasifikasi?'selected="selected"':'';?>>
                  							<?php echo $result['klasifikasi']; ?>
                  						</option>
                  					<?php endforeach; ?>
                  				</select>
				    		</div>	
                  		<?php } 
                  		}else{
                  			echo "Anda yakin untuk menghapus data ".$barang."";
                  		} ?>
			    		</div>
			    		<div style="float:right;">
			    		<?php 
				    		echo form_input(
				    			array(
				    				'data-dismiss' => 'modal',
				    				'name' 	=> 'modal-btn-close',
				    				'id' 	=> 'modal-btn-close',
				    				'type' 	=> 'button',
				    				'class' => 'btn btn-default',
				    				'value'	=> 'Keluar'
				    			)
				    		);
				    	?>		
			    		<?php 
			    		if ($operasi=="delete") {
								echo form_input(
				    				array(
				    					'name' 	=> 'btnHapusBarang',
				    					'id' 	=> 'btnHapusBarang',
				    					'type' 	=> 'button',
				    					'class' => 'btn btn-danger',
				    					'value'	=> 'Hapus'
				    				)
				    			);
			    		}
			    		?> 
				    		<?php
					    		if (!empty($query) && $operasi=="update") {					    			
				    				echo form_input(
				    					array(
				    						'name' 	=> 'btnUpdateBarang',
				    						'id' 	=> 'btnUpdateBarang',
				    						'type' 	=> 'button',
				    						'class' => 'btn btn-success',
				    						'value'	=> 'Perbarui'
				    					)
				    				);
					    		}else if ($operasi=="create"){  
				    				echo form_input(
				    					array(
				    						'name' 	=> 'btnSaveBarang',
				    						'id' 	=> 'btnSaveBarang',
				    						'type' 	=> 'button',
				    						'class' => 'btn btn-primary',
				    						'value'	=> 'Simpan'
				    					)
				    				);
				    			}
				    		?>		
				    	</div>
			    		<?php 
			    			echo form_close();
			    		?>
			    	</div>
			    </div>
	</div>