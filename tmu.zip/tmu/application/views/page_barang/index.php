<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<input type="hidden" value="barangPage" id="id_page">
<script type="text/javascript" language="javascript">

	$("#dataBarang").html("<div align='center'><i class='fa fa-spinner fa-spin fa-lg'></i></div>");
	var url = '<?php echo site_url("Controller_barang/loadData"); ?>';
	//alert(url);
	$.post(url, {} ,function(data) {
		$("#dataBarang").html(data).show();
	});
	
	var operasi		= "";
	var dataString	= "";
	var id			= "";
	var url 		= "";
	$('.ajax').click(function(e){
		e.preventDefault();
		$.get($(this).attr('href'), function(Res){
			$('#content_inti').html(Res);
		});
	})

	$('#tambahData').click(function(e){		
		operasi = "create"; 
		var url = "<?php echo site_url('controller_barang/formulir'); ?>";

		$('#myModal').fadeIn(400).modal('show');
		$(".modal-title").html("<i class='fa fa-archive'></i> Tambah Data Barang");
		//alert(url);
		$(".modal-body").html("<div align='center'><i class='fa fa-spinner fa-spin fa-lg'></i></div>");
		$.post(url, {operasi:operasi} ,function(data) {
			$(".modal-body").html(data).show();
		});
	});

	function editData(data){
		id 		= data;
		operasi = 'update';
		var url = '<?php echo site_url("Controller_barang/updateData"); ?>';

		$('#myModal').fadeIn(400).modal('show');
		$(".modal-title").html("Update Data");
		$(".modal-body").html("<div align='center'><i class='fa fa-spinner fa-spin fa-lg'></i></div>");

		$.post(url, {id:id, operasi:operasi} ,function(data) {
			$(".modal-body").html(data).show();
		});
	};

	function hapusData(data){	
		id 		= data;
		operasi = 'delete';
		var url = '<?php echo site_url("Controller_barang/deleteData"); ?>';

		$('#myModal').fadeIn(400).modal('show');
		$(".modal-title").html("Hapus Data");
		$(".modal-body").html("<div align='center'><i class='fa fa-spinner fa-spin fa-lg'></i></div>");

		$.post(url, {id:id, operasi:operasi} ,function(data) {
			$(".modal-body").html(data).show();
		});
	};
</script>
<input type="hidden" value="<?php echo $count; ?>" id="CountData">
<section class="content-header">
	<h1>
    	<?php echo $judul; ?> <small>Page</small>
	</h1>
	<ol class="breadcrumb">
    	<li><a href="<?php echo base_url(); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Barang</li>
	</ol>
</section>

<section class="content">
	<div class="row">
    	<a class="btn btn-app ajax" id="tambahData" href="javascript::;">
           	<i class="fa fa-plus"></i> Tambah
        </a>
    	<a class="btn btn-app ajax" id="" href="javascript::;">
           	<i class="fa fa-print"></i> Cetak
        </a>
    	<a class="btn btn-app ajax" id="" href="javascript::;">
           	<i class="fa fa-recycle"></i> Hapus Semua
        </a>

    	<div class="col-md-12">		
			<div class="box">
				<div class="box-body">
			    	<div class="row">
			        	<div class="col-md-12">
			        		<div id="dataBarang"></div>
						</div>
					</div><!-- /.row -->
				</div><!-- ./box-body -->
			</div><!-- /.box -->
		</div>
	</div>
</section>