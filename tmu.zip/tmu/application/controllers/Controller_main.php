<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Controller_main extends CI_Controller {
	
	function __construct(){
		parent::__construct();
		$this->load->library('template');
		$this->load->model('model_main','',TRUE);
		$this->load->helper(array('url','form'));
	}

	public function index()
	{
		$this->template->display(
			'welcome_message',
			array(
				'judul'=>'Selamat Datang',
				'count'=>$this->model_main->countDataBarang()
			)
		);
	}


	public function pageBarang()
	{	
		$this->template->display(
			'page_barang/index',
			array(
				'judul'		=> 'Barang',
				'count'		=> $this->model_main->countDataBarang(),
				'last_id' 	=> $this->model_main->lastIdDataBarang(),
				//'query' 	=> $this->model_main->dataBarang()
			)
		);
	}

	public function pageProyek()
	{	
		$this->template->display(
			'page_proyek/index',
			array(
				'judul'		=> 'Daftar Proyek',
				'count'		=> $this->model_main->countDataProyek(),
				'last_id' 	=> $this->model_main->lastIdDataProyek(),
				'query' 	=> $this->model_main->dataProyek()
			)
		);
	}

	public function pageKlasifikasi()
	{
		$data['judul']		= 'Klasifikasi';
		$data['count']		= $this->model_main->countDataKlasifikasi();
		$data['last_id']	= $this->model_main->lastIdDataKlasifikasi();
		$data['query']		= $this->model_main->dataKlasifikasi();
		$this->template->display('page_klasifikasi/index',$data);
	}

	public function pageBantuan()
	{
		$data['judul']		= 'Bantuan';
		$this->template->display('page_bantuan/index',$data);
	}
}
