<?php
if(!defined('BASEPATH')) exit('No direct script access allowed');

class Controller_item_proyek extends CI_Controller {
	private $id_barang, $id_satuan;

	function __construct(){
		parent::__construct();
		$this->load->database();
		$this->load->library('form_validation');
		$this->load->library('template');
		$this->load->model('model_item_proyek','',TRUE);
		$this->load->helper(array('url','form'));
	}

	public function getIdBarang(){
		return $this->id_barang;
	}

	public function getIdSatuan(){
		return $this->satuan;
	}

	public function index()
	{
		$this->template->display(
			'/page_barang/index',
			array(
				'judul'=>'Barang'
			)
		);
	}

	public function loadData()
	{
		$this->template->display(
			'/page_item_proyek/view',
			array(
				'query' 	=> $this->model_item_proyek->show(),
			)
		);
	}

	public function selectData()
	{
		$this->template->display(
			'/page_item_proyek/view',
			array(
				'query' 	=> $this->model_item_proyek->showSelectedData($this->input->post('id')),
			)
		);
	}

	public function lookUpBarang()
	{
		$keyword	= $this->input->post('term');
		$data['response'] = 'false';
		$query = $this->model_item_proyek->findBarang($keyword);
		if (!empty($query)) {
			$data['response'] = 'true';
			$data['message'] = array();
			foreach ($query as $row) {
				$data['message'][] = array(
					'id' 	=> $row['id'],
					'value'	=> $row['barang']//." - ".$row['spesifikasi'],
				);
			}
		}
		echo json_encode($data);
	}

	public function lookUpMerk()
	{
		$keyword	= $this->input->post('term');
		$data['response'] = 'false';
		$query = $this->model_item_proyek->findMerk($keyword);
		if (!empty($query)) {
			$data['response'] = 'true';
			$data['message'] = array();
			foreach ($query as $row) {
				$data['message'][] = array(
					'id' 	=> $row['id'],
					'value'	=> $row['merk']
				);
			}
		}
		echo json_encode($data);
	}

	public function lookUpType()
	{
		$keyword	= $this->input->post('term');
		$data['response'] = 'false';
		$query = $this->model_item_proyek->findType($keyword);
		if (!empty($query)) {
			$data['response'] = 'true';
			$data['message'] = array();
			foreach ($query as $row) {
				$data['message'][] = array(
					'id' 	=> $row['id'],
					'value'	=> $row['type']
				);
			}
		}
		echo json_encode($data);
	}

	public function lookUpSpesifikasi()
	{
		$keyword	= $this->input->post('term');
		$data['response'] = 'false';
		$query = $this->model_item_proyek->findSpesifikasi($keyword);
		if (!empty($query)) {
			$data['response'] = 'true';
			$data['message'] = array();
			foreach ($query as $row) {
				$data['message'][] = array(
					'id' 	=> $row['id'],
					'value'	=> $row['spesifikasi']
				);
			}
		}
		echo json_encode($data);
	}

	public function formulir()
	{
		$this->template->display(
			'page_barang/form',
			array(
				'judul'=>'Barang',
				'combo'=>$this->model_barang->comboKlasifikasi()
			)
		);
	}

	public function insert()
	{
		$cekSatuan = 	array( 'satuan' => $this->input->post('satuan'), );
		$querySatuan = $this->model_item_proyek->showSelectedSatuan($cekSatuan); 
		if ($querySatuan == false) {
			$this->model_item_proyek->saveDataSatuan($cekSatuan);
			$SatuanQuery = $this->model_item_proyek->showSatuan($cekSatuan); 
		}
		else{
			$SatuanQuery = $this->model_item_proyek->showSatuan($cekSatuan); 
		}
		foreach ($SatuanQuery as $rowSatuan) {
			$this->id_satuan = $rowSatuan['id'];
		}
				
		
		$cekBarang 	= 	array(
							'barang' 		=> $this->input->post('barang'),
							'spesifikasi' 	=> $this->input->post('spesifikasi'),
							'merk' 			=> $this->input->post('merk'),
							'type' 			=> $this->input->post('type'),
							'id_klasifikasi'=> 0,
						);
		$queryBarang= $this->model_item_proyek->showSelectedBarang($cekBarang); 
		if ($queryBarang == false) {
			$this->model_item_proyek->saveDataBarang($cekBarang);
			$BarangQuery = $this->model_item_proyek->showBarang($cekBarang); 
		}
		else{
			$BarangQuery = $this->model_item_proyek->showBarang($cekBarang); 
		}
		foreach ($BarangQuery as $rowBarang) {
			$this->id_barang = $rowBarang['id'];
		}
		
		
		$data = array(
			'id_proyek'		=> $this->input->post('id_proyek'),
			'id_barang'		=> $this->id_barang,
			'id_satuan'		=> $this->id_satuan,
			'quantity'		=> $this->input->post('jumlah'),
			'harga'			=> 0,
			'keterangan'	=> $this->input->post('keterangan'),
			'tanggal_dibutuhkan' => $this->input->post('tanggal')
		);
		$this->model_item_proyek->save($data);
		echo json_encode($data);
	}

	public function update(){
		$key  = $this->input->post('id'); 
		$data = array(
					'id_klasifikasi'=>$this->input->post('klasifikasi'),
					'barang'		=>$this->input->post('barang'),
					'spesifikasi'	=>$this->input->post('spesifikasi'),
					'merk'			=>$this->input->post('merk'),
					'type'			=>$this->input->post('type'),
				);
		$this->model_barang->update($key, $data);
	}

	public function delete()
	{
		$this->model_barang->delete($this->input->post('id'));
	}

	public function updateData(){
		$data['combo'] = $this->model_barang->comboKlasifikasi();
		$data['query'] = $this->model_barang->showSelectedData($this->input->post('id')); 
		$this->load->view('/page_barang/form', $data);
	}
}
