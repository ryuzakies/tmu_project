<?php
if(!defined('BASEPATH')) exit('No direct script access allowed');

class Controller_proyek extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->library('form_validation');
		$this->load->library('template');
		$this->load->model('model_proyek','',TRUE);
		$this->load->helper(array('url','form'));
	}

	public function index()
	{
		$this->template->display(
			'/page_proyek/index',
			array(
				'judul'=>'Daftar Proyek'
			)
		);
	}

	public function loadData()
	{
		$this->template->display(
			'/page_proyek/view',
			array(
				'query' 	=> $this->model_proyek->show(),
			)
		);
	}

	public function pageItem($id)
	{
		$this->template->display(
			'/page_item_proyek/index',
			array(
				'judul'		=> 'Daftar Item Proyek',
				'item'		=> $this->model_proyek->showSelectedData($id),
				'count' 	=> $this->model_proyek->countDataItemProyek()
			)
		);
	}

	public function formulir()
	{
		$this->template->display('page_proyek/form',
			array(
				'judul'		=> 'Barang',
				'operasi'	=> $this->input->post('operasi'),
			)
		);
	}

	public function editData(){
		$data['operasi']	= $this->input->post('operasi');
		$data['query'] 		= $this->model_proyek->showSelectedData($this->input->post('id')); 
		$this->load->view('/page_proyek/form', $data);
	}

	public function insert()
	{
		$data = array(
			'nomer_proyek' 	=> $this->input->post('nomer'),
			'lokasi_proyek'	=> $this->input->post('lokasi'),
			'tanggal'		=> $this->input->post('tanggal'),
			'nama_proyek'	=> $this->input->post('proyek')
		);
		$this->model_proyek->save($data);
		echo json_encode($data);
	}

	public function delete()
	{
		$this->model_proyek->delete($this->input->post('id'));
		$data['id'] = $this->input->post('id');
		echo json_encode($data);
	}

	public function update(){
		$key  = $this->input->post('id'); 
		$data = array(
					'nomer_proyek'	=>$this->input->post('nomer'),
					'lokasi_proyek'	=>$this->input->post('lokasi'),
					'tanggal'		=>$this->input->post('tanggal'),
					'nama_proyek'	=>$this->input->post('proyek')
				);
		$this->model_proyek->update($key, $data);
		echo json_encode($data);
	}
}
