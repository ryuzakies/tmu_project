<?php
if(!defined('BASEPATH')) exit('No direct script access allowed');

class Controller_barang extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->library('form_validation');
		$this->load->library('template');
		$this->load->model('model_barang','',TRUE);
		$this->load->helper(array('url','form'));
	}

	public function index()
	{
		$this->template->display(
			'/page_barang/index',
			array(
				'judul'		=>'Barang',
			)
		);
	}

	public function loadData()
	{	
		if (empty($this->input->post('id'))) {
			$data['query'] 	= $this->model_barang->show('');
		}else{
			$data['query'] 	= $this->model_barang->show($this->input->post('id'));
		}

		$this->template->display(
			'/page_barang/view',
			$data
		);
	}

	public function formulir()
	{
		$this->template->display(
			'page_barang/form',
			array(
				'judul'		=> 'Barang',
				'operasi'	=> $this->input->post('operasi'),
				'combo'		=> $this->model_barang->comboKlasifikasi()
			)
		);
	}

	public function insert()
	{
		$data = array(
			'id_klasifikasi'=> $this->input->post('klasifikasi'),
			'barang' 		=> $this->input->post('barang'),
			'spesifikasi'	=> $this->input->post('spesifikasi'),
			'merk'			=> $this->input->post('merk'),
			'type'			=> $this->input->post('type')
		);
		$this->model_barang->save($data);
		$query = $this->model_barang->showSelectedAllData($data);
		foreach ($query as $row) {
			$data['id'] 	= $row['id'];
		}
		echo json_encode($data);
	}

	public function update(){
		$key  = $this->input->post('id'); 
		$data = array(
					'id_klasifikasi'=>$this->input->post('klasifikasi'),
					'barang'		=>$this->input->post('barang'),
					'spesifikasi'	=>$this->input->post('spesifikasi'),
					'merk'			=>$this->input->post('merk'),
					'type'			=>$this->input->post('type')
				);
		$this->model_barang->update($key, $data);
		$query = $this->model_barang->showSelectedKlasifikasi($data['id_klasifikasi']);
		foreach ($query as $row) {
			$data['klasifikasi'] = $row['klasifikasi'];
		}
		echo json_encode($data);
	}

	public function delete()
	{
		$this->model_barang->delete($this->input->post('id'));
		$data['id'] 	= $this->input->post('id');
		echo json_encode($data);
	}

	public function updateData(){
		$data['operasi']= $this->input->post('operasi');
		$data['combo'] 	= $this->model_barang->comboKlasifikasi();
		$data['query'] 	= $this->model_barang->showSelectedData($this->input->post('id')); 
		$this->load->view('/page_barang/form', $data);
	}

	public function deleteData(){
		$data['operasi'] 	= $this->input->post('operasi');
		$data['query'] 		= $this->model_barang->showSelectedData($this->input->post('id')); 
		$this->load->view('/page_barang/form', $data);
	}
}
