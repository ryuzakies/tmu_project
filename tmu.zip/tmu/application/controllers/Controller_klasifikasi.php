<?php
if(!defined('BASEPATH')) exit('No direct script access allowed');

class Controller_klasifikasi extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->library('form_validation');
		$this->load->library('template');
		$this->load->model('model_klasifikasi_barang','',TRUE);
		$this->load->helper(array('url','form'));
	}

	public function index()
	{
		$this->template->display(
			'/page_barang/index',
			array(
				'judul'=>'Klasifikasi'
			)
		);
	}

	public function loadData()
	{
		$this->template->display(
			'/page_klasifikasi/view',
			array(
				'query' 	=> $this->model_klasifikasi_barang->show(),
			)
		);
	}

	public function formulir()
	{
		$this->template->display(
			'page_klasifikasi/form',
			array(
				'judul'		=> 'Klasifikasi',
				'operasi'	=> $this->input->post('operasi')
			)
		);
	}

	public function updateData(){
		$data['operasi']	= $this->input->post('operasi');
		$data['query'] 		= $this->model_klasifikasi_barang->showSelectedData($this->input->post('id')); 
		$this->load->view('/page_klasifikasi/form', $data);
	}

	public function insert()
	{
		$data = array(
			'klasifikasi' 	=> $this->input->post('klasifikasi'),
			'deskripsi' 	=> $this->input->post('deskripsi')
		);
		$this->model_klasifikasi_barang->save($data);
		echo json_encode($data);
	}

	public function delete()
	{
		$this->model_klasifikasi_barang->delete($this->input->post('id'));
		$data['id'] 	= $this->input->post('id');
		echo json_encode($data);
	}

	public function update(){
		$key  = $this->input->post('id'); 
		$data = array(
					'klasifikasi'	=>$this->input->post('klasifikasi'),
					'deskripsi'		=>$this->input->post('deskripsi'),
				);
		$this->model_klasifikasi_barang->update($key, $data);
		echo json_encode($data);
	}

	public function deleteData(){
		$data['operasi'] 	= $this->input->post('operasi');
		$data['query'] 		= $this->model_klasifikasi_barang->showSelectedData($this->input->post('id')); 
		$this->load->view('/page_klasifikasi/form', $data);
	}
}
